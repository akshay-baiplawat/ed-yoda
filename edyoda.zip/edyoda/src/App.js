
import './App.css';
import { Body, NavBar } from './components';

function App() {
  return (
    <div className="App">
      <NavBar/>
      <Body/>
    </div>
  );
}

export default App;
