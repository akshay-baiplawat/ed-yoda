export { default as NavBar } from './NavBar';
export { default as Body } from './Body';
export { default as MainLockup } from './MainLockup';
export { default as Form } from './Form';
export { default as PriceClick } from './PriceClick';